<?php $__env->startSection('content'); ?>
<!-- Main-start -->
<section class="hero">
    <div class="container mb-5">
        <div class="row align-items-center">

            <div class="col-lg-6">
                <h1 class="hero-heading mb-0">The industry's leading<br>channel manager</h1>
                <div class="main-btns d-flex justify-content-center">
                    <a class="btn btn-primary mt-4 mr-3" href="#">Document</a>
                    <a class="btn btn-outline-primary mt-4 ml-3" href="#">Application</a>
                </div>
            </div>

            <div class="col-lg-6 landing-art">
                <img src="/Assets/clouds.svg" alt="" class="clouds x1">
                <img src="/Assets/tokyo.svg" alt="" class="tokyo-img">
            </div>

        </div>
    </div>
</section>
<!-- Main-end -->

<!-- Partners-logos-start -->
<section class="partners-sec">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div>
                    <div class="partners-heading text-center">
                        <p class="text-muted">Trusted by companies worldwide</p>
                    </div>
                    <div class="partners-list">
                        <ul class="list-unstyled d-flex">
                            <li><img src="/Assets/jtb.svg" alt="jtb" class="partners-img"></li>
                            <li><img src="/Assets/Airbnb.svg" alt="bnb" class="partners-img"></li>
                            <li><img src="/Assets/Booking.svg" alt="bkng" class="partners-img"></li>
                            <li><img src="/Assets/Hotelbeds.svg" alt="hb" class="partners-img"></li>
                            <li><img src="/Assets/rakuten.svg" alt="rkt" class="partners-img"></li>
                            <li><img src="/Assets/expedia-vector-logo.svg" alt="exp" class="partners-img">
                            </li>
                            <li><img src="./Assets/agoda-vector-logo.svg" alt="tpad" class="partners-img"></li>
                            <li><img src="./Assets/tripadvisor.svg" alt="exp" class="partners-img">
                        </ul>
                    </div>
                    <div class="text-center linked">
                        <a href="#" class="arrow-link">Linked Sites <img src="./Assets/right-arrow-svg.svg"
                                alt="arrow"></a>
                        <a href="#" class="arrow-link">Linked PMS <img src="./Assets/right-arrow-svg.svg"
                                alt="arrow"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Partners-logos-end -->


<!-- Features-start -->
<section class="services-sec">
    <div class="container">
        <div class="text-center">
            <h3 class="services-title underline">Why Temairazu?</h3>
            <p class="text-muted">"Being a world-class reservation site controller we strive to deliver premium
                features"
            </p>
        </div>
        <div class="row cards">
            <div class="col-12 col-sm-6 col-lg-3 d-flex">
                <div class="card">
                    <div class="text-center">
                        <h5 class="card-title">Diversify customer acquisition channels</h5>
                    </div>
                    <div class="card-image text-center">
                        <img src="./Assets/multichannel.svg" alt="customer-aquisition">
                    </div>
                    <div class="card-body">
                        <p>The room information can be posted on various reservation sites, this feature
                            increases the chances of accomodation reservation.</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3 d-flex">
                <div class="card">
                    <div class="text-center">
                        <h5 class="card-title">Opportunity loss prevention</h5>
                    </div>
                    <div class="card-image text-center">
                        <img src="./Assets/magnify-new-2.svg" alt="magnify">
                    </div>
                    <div class="card-body">
                        <p>You can centrally manage the inventory of multiple accommodation reservation sites,
                            reaching multiple potential
                            customers.</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3 d-flex">
                <div class="card">
                    <div class="text-center">
                        <h5 class="card-title">Management cost reduction</h5>
                    </div>
                    <div class="card-image text-center">
                        <img src="./Assets/coins.svg" alt="coins">
                    </div>
                    <div class="card-body">
                        <p>Updates to each site can be managed automatically 24x7,
                            improving work efficiency, reducing
                            management costs and unifying work flow.</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-lg-3 d-flex">
                <div class="card last-card">
                    <div class="text-center">
                        <h5 class="card-title">Fast and secure updates</h5>
                    </div>
                    <div class="card-image text-center">
                        <img src="./Assets/speed.svg" alt="speed">
                    </div>
                    <div class="card-body">
                        <p>Reservation information acquisition interval is short and overbooking is suppressed
                            enhancing speed of work.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Features-end -->


<!-- Updates-start -->
<section class="updates-sec" id="updates">
    <div class="container">
        <div class="text-center mb-4">
            <h3 class="updates-title underline">Updates</h3>
        </div>
        <div class="row">

            <!-- Update-start -->
            <div class="col-lg-7 d-flex">
                <div class="updates-col">
                    <p class="d-flex justify-content-center"><img src="./Assets/New.svg" alt="new" class="new"></p>
                    <p class="update-heading text-center">Reservation acquisition function update</p>
                    <p class="update-subject text-center">Accelerate reservation acquisition for all versions of
                        the
                        TEMAIRAZU series</p>
                    <div class="update-button d-flex justify-content-center mb-3">
                        <a class="btn btn-outline-primary" href="#">Update
                            Overview</a>
                    </div>
                </div>
            </div>
            <!-- Update-end -->

            <!-- News-start -->
            <div class="col-lg-5">
                <div class="news-col">
                    <h3 class="news-title text-center underline">News</h3>
                    <div class="container">

                        <div class="news-body">
                            <div class="row news-row">
                                <a href="" class="news-headline">Matters concerning controlling shareholders,
                                    etc.</a>
                            </div>
                            <div class="row news-cols">
                                <div class="col-mb-4">
                                    <p><a href="#" style="color: #0275d8;">Press Release</a></p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted">24 September 2019</p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted"><img src="./Assets/adobe.svg" alt="adobe"></p>
                                </div>
                            </div>
                        </div>

                        <div class="news-body">
                            <div class="row">
                                <a href="" class="news-headline">Matters concerning controlling shareholders,
                                    etc.</a>
                            </div>
                            <div class="row news-cols">
                                <div class="col-mb-4">
                                    <p><a href="#">Press Release</a></p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted">24 September 2019</p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted"><img src="./Assets/adobe.svg" alt="adobe"></p>
                                </div>
                            </div>
                        </div>

                        <div class="news-body">
                            <div class="row">
                                <a href="" class="news-headline">Matters concerning controlling shareholders,
                                    etc.</a>
                            </div>
                            <div class="row news-cols">
                                <div class="col-mb-4">
                                    <p><a href="#">IR News</a></p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted">24 September 2019</p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted"><img src="./Assets/html.svg" alt="adobe"></p>
                                </div>
                            </div>
                        </div>

                        <div class="news-body">
                            <div class="row">
                                <a href="" class="news-headline">Matters concerning controlling shareholders,
                                    etc.</a>
                            </div>
                            <div class="row news-cols">
                                <div class="col-mb-4">
                                    <p><a href="#">IR News</a></p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted">24 September 2019</p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted"><img src="./Assets/html.svg" alt="adobe"></p>
                                </div>
                            </div>
                        </div>

                        <div class="news-body">
                            <div class="row">
                                <a href="" class="news-headline">Matters concerning controlling shareholders,
                                    etc.</a>
                            </div>
                            <div class="row news-cols">
                                <div class="col-mb-4">
                                    <p><a href="#">Press Release</a></p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted">24 September 2019</p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted"><img src="./Assets/adobe.svg" alt="adobe"></p>
                                </div>
                            </div>
                        </div>

                        <div class="news-body">
                            <div class="row">
                                <a href="" class="news-headline">Engine “t-switch”
                                    installed in Airbnb ’s “Cloud PMS”</a>
                            </div>
                            <div class="row news-cols">
                                <div class="col-mb-4">
                                    <p><a href="#">IR News</a></p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted">24 September 2019</p>
                                </div>
                                <p class="text-muted">|</p>
                                <div class="col-mb-4">
                                    <p class="text-muted"><img src="./Assets/html.svg" alt="adobe"></p>
                                </div>
                            </div>
                            <div class="row news-btn-row">
                                <a class="btn btn-primary btn-sm mr-3" href="#">PR News List</a>
                                <a class="btn btn-primary btn-sm ml-3" href="#">IR News List</a>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- News-end -->

            </div>
        </div>
    </div>
</section>
<!-- Updates-end -->


<!-- Dantai-start -->
<section class="dantai-travel-sec">
    <div class="container mb-5">
        <h3 class="text-center underline">Temairazu Dantai Travel</h3>
        <div class="row align-items-center">
            <div class="col-lg-6 content-col">
                <p class="heading">Centralized management of group accommodation reservations</p>
                <hr>
                <p class="content">Group accommodation reservations can be managed with TEMAIRAZU.
                    Both personal and group accommodation reservations are managed
                    together, and travel reservations done by phone, fax, and e-mail
                    are freed from the complexity of managing paper ledgers and spreadsheets.</p>
                <div class="dantai-button">
                    <a class="btn btn-outline-primary" href="#">Temairazu Dantai Travel</a>
                </div>
            </div>
            <div class="col-lg-6">
                <img src="./Assets/dantai-travel.svg" alt="dantai-travel" class="dantai-travel-img">
            </div>
        </div>
    </div>
</section>
<!-- Dantai-end -->


<!-- Multi-start -->
<section class="multi-sec">
    <div class="container mb-5">
        <h3 class="text-center underline">Multi-Platform Support</h3>
        <div class="row align-items-center wp-multi pt-5">
            <div class="col-lg-6">
                <img src="./Assets/Multi-platform.svg" alt="multi" class="multi-img">
            </div>
            <div class="col-lg-6 content-col">
                <p class="heading">Can be managed anywhere if connected to the Internet</p>
                <hr>
                <p class="content">Because it is an ASP-type service, it can be not only operable on PC
                    but also
                    on
                    smartphones and tablets
                    if there is an environment that can connect to the Internet. In addition, it can be managed
                    from multiple terminals
                    connected to the Internet, and can be accessed and managed from anywhere, such as the front
                    desk
                    of the accommodation
                    facility or the office of the group headquarters.</p>
                <div class="multi-button">
                    <a class="btn btn-outline-primary" href="#">More details</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Multi-end -->


<!-- Careers-start -->
<section class="careers-sec" id="careers">
    <div class="container mb-5">
        <div class="hiring text-center">
            <h3 class="text-center underline">We're Hiring</h3>
            <div class="col-lg-8 mx-auto">
                <img src=" ./Assets/Hiring.svg" alt="" class="hiring-img">
            </div>
            <div class="col-lg-8 mx-auto">
                <p>Being a leading site controller, Temairazu broadens the options
                    for travelers and creates a virtuous circle in the travel industry. What we are doing is
                    “supporting the travel industry”. Why don't you use your experience to grow one of the
                    biggest
                    industries in Japan?
                </p>
            </div>
            <div class="col-lg-8 mx-auto">
                <a href="#" class="arrow-link">People who work without hassle
                    <img src="./Assets/right-arrow-svg.svg"></a>
            </div>
            <div class="container">
                <div class="row links">
                    <div>
                        <a href="#" class="col-lg-3 arrow-link">Employment Information
                            <img src="./Assets/right-arrow-svg.svg"></a>
                    </div>
                    <div>
                        <a href="#" class="col-lg-3 arrow-link">Representative Message
                            <img src="./Assets/right-arrow-svg.svg"></a>
                    </div>
                    <div>
                        <a href="#" class="col-lg-3 arrow-link">New graduate recruitment
                            <img src="./Assets/right-arrow-svg.svg"></a>
                    </div>
                    <div>
                        <a href="#" class="col-lg-3 arrow-link">Mid-career recruitment
                            <img src="./Assets/right-arrow-svg.svg"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Careers-end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\Temairazu\Temairazu-Laravel\resources\views/home.blade.php ENDPATH**/ ?>