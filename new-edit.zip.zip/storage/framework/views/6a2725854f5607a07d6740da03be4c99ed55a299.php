<div class="col-lg-5">
    <div class="news-col">
        <h3 class="news-title text-center underline">News</h3>
        <div class="container">

            <?php $__currentLoopData = $data->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i<5): ?> <div class="news-body">
                <div class="row news-row">
                    <a href="" class="news-headline"><?php echo e($api->title); ?></a>
                </div>
                <div class="row news-cols">
                    <div class="col-mb-4">
                        <p><a href="#" style="color: #0275d8;">Press Release</a></p>
                    </div>
                    <p class="text-muted">|</p>
                    <div class="col-mb-4">
                        <p class="text-muted">24 September 2019</p>
                    </div>
                    <p class="text-muted">|</p>
                    <div class="col-mb-4">
                        <p class="text-muted"><img src="./Assets/adobe.svg" alt="adobe"></p>
                    </div>
                </div>
                <?php echo e($i=$i+1); ?>

        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>
<?php /**PATH P:\Temairazu\Temairazu-Laravel\resources\views/internals/news.blade.php ENDPATH**/ ?>